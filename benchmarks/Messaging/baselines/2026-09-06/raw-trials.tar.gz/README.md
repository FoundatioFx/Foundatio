# Raw messaging benchmark evidence

- `standard` and `extended`: the initial complete matrix, before the in-memory timer fix. Failed trials are preserved.
- `memory-fixed` and `memory-extended-fixed`: repeated in-memory comparisons after commit `6a1a9887`.
- `soak`: two-minute trials after that fix. The failed Redis warmup and its explicitly named second attempt are both retained.
- `rate` and `loopback`: the same built executable used for `soak`, with every option and runtime/library version in the JSON. These extra cases were invoked individually; host/runtime metadata is shared with `soak`.

Each standard configuration has three trials. Extended, offered-rate and loopback cases have one trial each. See the results report for limitations. Log files and unsuccessful JSON records are evidence, not successful measurements. Native dumps remain local and are not included here. The default output directories are ignored by Git; this directory is an intentional baseline snapshot.
