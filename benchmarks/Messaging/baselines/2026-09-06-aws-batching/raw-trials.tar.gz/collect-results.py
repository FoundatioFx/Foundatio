import collections, json, pathlib, statistics
base = pathlib.Path(__file__).parent
profiles = ['final-standard', 'adaptive-check', 'confirmed-standard', 'confirmed-rate10', 'confirmed-rate100', 'confirmed-soak', 'confirmed-requests']
summary = {}
for profile in profiles:
    groups = collections.defaultdict(list)
    for path in sorted((base / profile).glob('*/round*.json')):
        result = json.loads(path.read_text())
        m, o = result['Measurement'], result['Options']
        assert result['Success'] and result['Error'] is None, path
        assert m['Error'] is None and m['FirstInvalid'] is None, path
        assert m['Deliveries'] == m['Inputs'] * o['DeliveryCopies'], path
        assert m['DeliveryLatency']['Count'] == m['Deliveries'], path
        assert m['Missing'] == m['Duplicates'] == m['Invalid'] == 0, path
        assert not m['HitTrackingLimit'], path
        assert m['PublishSeconds'] >= o['DurationSeconds'] - 0.001, path
        assert m['TotalSeconds'] >= m['PublishSeconds'], path
        assert abs(m['InputsPerSecond'] - m['Inputs'] / m['TotalSeconds']) < 1e-6, path
        assert all(0 <= s['Outstanding'] <= o['MaxOutstanding'] for s in m['Samples']), path
        workload = path.stem.split('-', 1)[1]
        groups[path.parent.name + '/' + workload].append(m)
    rows = {}
    for key, ms in groups.items():
        med = lambda f: statistics.median(f(m) for m in ms)
        rows[key] = dict(trials=len(ms), inputs=sum(m['Inputs'] for m in ms), deliveries=sum(m['Deliveries'] for m in ms),
            throughput=med(lambda m:m['InputsPerSecond']), minimum=min(m['InputsPerSecond'] for m in ms), maximum=max(m['InputsPerSecond'] for m in ms),
            p50=med(lambda m:m['DeliveryLatency']['P50Milliseconds']), p95=med(lambda m:m['DeliveryLatency']['P95Milliseconds']),
            p99=med(lambda m:m['DeliveryLatency']['P99Milliseconds']), sendP99=med(lambda m:m['SendCallLatency']['P99Milliseconds']),
            bytes=med(lambda m:m['AllocatedBytesPerInput']), cpu=med(lambda m:m['CpuMilliseconds']/m['Inputs']),
            peakMiB=med(lambda m:m['PeakWorkingSetBytes']/1048576), admitted=med(lambda m:m['Inputs']/m['PublishSeconds']))
    summary[profile] = rows
(base / 'analysis.json').write_text(json.dumps(summary, indent=2))
for profile, rows in summary.items():
    print(profile, sum(r['trials'] for r in rows.values()), 'validated trials')
    for key, row in sorted(rows.items()):
        print(f"  {key:25} {row['throughput']:8.1f}/s [{row['minimum']:.1f}, {row['maximum']:.1f}] p99 {row['p99']:.2f} ms")
