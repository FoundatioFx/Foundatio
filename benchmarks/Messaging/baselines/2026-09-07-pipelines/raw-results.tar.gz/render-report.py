import json,pathlib,subprocess
base=pathlib.Path('/tmp/foundatio-fastest')
subprocess.run(['python3',str(base/'summarize.py')],stdout=subprocess.DEVNULL,check=True)
rows=json.loads((base/'confirmed-summary.json').read_text())
lookup={(r['Profile'],r['Variant'],r['Workload']):r for r in rows}
def get(p,v,w): return lookup.get((p,v,w))
def number(v,digits=0): return f'{v:,.{digits}f}'
def table(headers,items): return '\n'.join(['| '+' | '.join(headers)+' |','| '+' | '.join(['---']*len(headers))+' |',*['| '+' | '.join(map(str,row))+' |' for row in items]])
sections=[]
items=[]
for p,t,ws in [('confirmed-memory','Memory',['serial','queue','fanout']),('confirmed-aws','LocalStack',['serial','queue','pubsub-one','fanout'])]:
 for w in ws:
  f=get(p,'after',w); m=get(p,'masstransit',w)
  if not f or not m: continue
  items.append([t+' / '+w,number(f['InputsPerSecond']),number(m['InputsPerSecond']),f"{f['InputsPerSecond']/m['InputsPerSecond']:.2f}x",number(f['P99Milliseconds'],2),number(m['P99Milliseconds'],2)])
sections.append('## Repeated standard comparison\n\n'+table(['Transport / workload','Foundatio inputs/s','MassTransit inputs/s','Throughput ratio','Foundatio p99 ms','MassTransit p99 ms'],items)+'\n\nThe four-subscriber LocalStack fanout medians are effectively tied: the small difference falls within overlapping observed ranges. In-memory and other standard AWS medians favor Foundatio. These results establish performance for this matrix and environment, not universal dominance across workloads, brokers or latency/throughput objectives.')
items=[]
for p,t in [('confirmed-memory','Memory'),('confirmed-redis','Redis')]:
 for w in ['serial','queue','fanout']:
  f=get(p,'after',w); b=get(p,'before',w)
  if not f or not b:continue
  items.append([t+' / '+w,number(b['InputsPerSecond']),number(f['InputsPerSecond']),f"{f['InputsPerSecond']/b['InputsPerSecond']:.2f}x"])
sections.append('## Preserved implementation comparison\n\n'+table(['Transport / workload','Before inputs/s','After inputs/s','Ratio'],items)+'\n\nMemory concurrent queues and both Redis cases are close to their previous throughput; the larger gains are in memory serial queues and AWS. The earlier same-runtime AWS comparison is retained separately as `official-aws`; it measured the intermediate `d07031ff` implementation against the preserved build and MassTransit. Do not merge that intermediate comparison into the final repetitions.')
items=[]
for p,label in [('confirmed-16k','16 KiB'),('confirmed-batch10','Batch of ten')]:
 for w in ['queue','fanout']:
  f=get(p,'after',w);m=get(p,'masstransit',w)
  if f and m:items.append([label+' / '+w,number(f['InputsPerSecond']),number(m['InputsPerSecond']),number(f['P99Milliseconds'],2),number(m['P99Milliseconds'],2)])
sections.append('## Payload and batch checks\n\nOne fifteen-second trial per cell, with three seconds of warmup. These are checks of additional workloads, not repeated confidence estimates.\n\n'+table(['LocalStack case','Foundatio inputs/s','MassTransit inputs/s','Foundatio p99 ms','MassTransit p99 ms'],items)+'\n\nExplicit batches use eight producer workers and ten inputs per API call. The batch API comparisons favor Foundatio throughput, but the sampled batch p99 values favor MassTransit. Throughput gains do not imply winning every latency statistic.')
items=[]
for p,rate in [('confirmed-rate10',10),('confirmed-rate100',100)]:
 for w in ['queue','fanout']:
  f=get(p,'after',w);m=get(p,'masstransit',w)
  if f and m:items.append([str(rate)+' / '+w,number(f['InputsPerSecond'],1),number(m['InputsPerSecond'],1),number(f['P99Milliseconds'],2),number(m['P99Milliseconds'],2)])
sections.append('## Offered rates and round trips\n\nOne twenty-second trial per offered-rate cell. Latency starts at the intended schedule, including capacity waits. Both implementations achieved the configured offered rates to rounding.\n\n'+table(['Target inputs/s / workload','Foundatio completed/s','MassTransit completed/s','Foundatio p99 ms','MassTransit p99 ms'],items))
f=get('confirmed-roundtrip','after','serial');m=get('confirmed-roundtrip','masstransit','serial')
if f and m: sections[-1]+=f"\n\nWith one input outstanding, one producer and one consumer, the repeated queue round-trip medians were {number(f['InputsPerSecond'])} completed inputs/s and {number(f['P99Milliseconds'],2)} ms p99 for Foundatio, versus {number(m['InputsPerSecond'])} inputs/s and {number(m['P99Milliseconds'],2)} ms for MassTransit. This window-one test is separate from the standard serial saturation case."
items=[]
for p in ['confirmed-soak-aws','confirmed-soak-memory','confirmed-soak-redis']:
 for r in rows:
  if r['Profile']!=p:continue
  items.append([p.removeprefix('confirmed-soak-')+' / '+r['Variant']+' / '+r['Workload'],number(r['Inputs']),number(r['InputsPerSecond']),number(r['P99Milliseconds'],2),number(r['PeakWorkingSetMiB'],1)])
sections.append('## Two-minute soaks\n\nOne 120-second publishing window per cell after five seconds of warmup; every admitted input is drained and validated. All soak variants reserve the same 100-million-input tracking capacity, compared with 20 million for the shorter profiles. RSS therefore must not be compared directly across these profile types.\n\n'+table(['Transport / implementation / workload','Inputs','Inputs/s','p99 ms','Peak working set MiB'],items))
items=[]
for p,t,ws in [('confirmed-memory','Memory',['serial','queue','fanout']),('confirmed-aws','LocalStack',['serial','queue','pubsub-one','fanout'])]:
 for w in ws:
  f=get(p,'after',w);m=get(p,'masstransit',w)
  if f and m:items.append([t+' / '+w,number(f['AllocatedBytesPerInput']),number(m['AllocatedBytesPerInput']),number(f['CpuMillisecondsPerInput'],3),number(m['CpuMillisecondsPerInput'],3)])
sections.append('## Client cost\n\n'+table(['Transport / workload','Foundatio bytes/input','MassTransit bytes/input','Foundatio CPU ms/input','MassTransit CPU ms/input'],items)+'\n\nAWS fanout allocation remains higher for Foundatio. The 16 KiB checks also allocate more for Foundatio: '+(f"{number(get('confirmed-16k','after','queue')['AllocatedBytesPerInput'])} versus {number(get('confirmed-16k','masstransit','queue')['AllocatedBytesPerInput'])} bytes/input for queues, and {number(get('confirmed-16k','after','fanout')['AllocatedBytesPerInput'])} versus {number(get('confirmed-16k','masstransit','fanout')['AllocatedBytesPerInput'])} for fanout." if get('confirmed-16k','masstransit','fanout') else 'pending.')+' Client allocation, end-to-end throughput and tail latency are separate measurements; no across-the-board allocation claim is made.')
text=(base/'report-notes.md').read_text()
text=text.replace('## Changes','\n\n'.join(sections)+'\n\n## Changes')
(base/'report-draft.md').write_text(text)
print('Draft updated:',sum(r['Trials'] for r in rows),'trials,',sum(r['Inputs'] for r in rows),'inputs,',sum(r['Deliveries'] for r in rows),'deliveries')
