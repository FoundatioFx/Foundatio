import json, pathlib, subprocess
base=pathlib.Path('/tmp/foundatio-fastest')
profiles=[
 ('confirmed-memory', ['--transport','memory','--variants','before,after,masstransit','--workloads','serial,queue,fanout']),
 ('confirmed-aws', ['--variants','after,masstransit','--workloads','serial,queue,pubsub-one,fanout']),
 ('confirmed-redis', ['--transport','redis','--variants','before,after','--workloads','queue,fanout']),
 ('confirmed-16k', ['--variants','after,masstransit','--workloads','queue,fanout','--payload','16384','--repetitions','1','--seconds','15']),
 ('confirmed-batch10', ['--variants','after,masstransit','--workloads','queue,fanout','--batch','10','--repetitions','1','--seconds','15']),
 ('confirmed-rate10', ['--variants','after,masstransit','--workloads','queue,fanout','--rate','10','--repetitions','1','--seconds','20']),
 ('confirmed-rate100', ['--variants','after,masstransit','--workloads','queue,fanout','--rate','100','--repetitions','1','--seconds','20']),
 ('confirmed-roundtrip', ['--variants','after,masstransit','--workloads','serial','--window','1','--repetitions','3']),
 ('confirmed-soak-aws', ['--variants','after,masstransit','--workloads','queue,fanout','--repetitions','1','--seconds','120','--warmup','5','--max-messages','100000000']),
 ('confirmed-soak-memory', ['--transport','memory','--variants','after,masstransit','--workloads','fanout','--repetitions','1','--seconds','120','--warmup','5','--max-messages','100000000']),
 ('confirmed-soak-redis', ['--transport','redis','--variants','after','--workloads','queue,fanout','--repetitions','1','--seconds','120','--warmup','5','--max-messages','100000000']),
]
(base/'confirmed-profiles.json').write_text(json.dumps(profiles,indent=2))
for name,args in profiles:
 print('\nPROFILE '+name,flush=True)
 command=['python3',str(base/'compare.py'),'--output',str(base/name),'--dotnet',str(base/'official-dotnet/dotnet'),*args]
 result=subprocess.run(command)
 if result.returncode:
  print('FAILED PROFILE '+name+'; remaining profiles not started',flush=True)
  raise SystemExit(result.returncode)
print('ALL PROFILES COMPLETED',flush=True)
