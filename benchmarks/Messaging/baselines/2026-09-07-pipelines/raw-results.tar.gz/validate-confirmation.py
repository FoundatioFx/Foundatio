import hashlib,json,pathlib
base=pathlib.Path('/tmp/foundatio-fastest')
profiles=json.loads((base/'confirmed-profiles.json').read_text())
expected_hash=json.loads((base/'runtime-provenance.json').read_text())['microsoft']['coreclr_sha256'].lower()
seen=set();trials=inputs=deliveries=0
for name,_ in profiles:
 root=base/name
 opts=json.loads((root/'run-options.json').read_text())
 manifest=json.loads((root/'binary-manifest.json').read_text())
 assert manifest['after_revision']=='77c20ea354919fd25ae300e49c5de7f3ed8da598',name
 assert not (root/'source.patch').read_text().strip(),name
 assert opts['dotnet']==str(base/'official-dotnet/dotnet'),name
 assert not list(root.rglob('*-failure.txt')),name
 for variant in opts['variants'].split(','):
  for workload in opts['workloads'].split(','):
   for repeat in range(1,opts['repetitions']+1):
    p=root/variant/f'round{repeat}-{workload}.json'
    r=json.loads(p.read_text());m=r['Measurement'];o=r['Options']
    assert r['Success'] and not r['Error'] and not m['Error'],p
    assert not any(m[k] for k in ('Missing','Duplicates','Invalid','HitTrackingLimit')),p
    assert m['Inputs']>0 and m['Deliveries']==m['Inputs']*o['DeliveryCopies'],p
    assert m['DeliveryLatency']['Count']==m['Deliveries'],p
    assert m['PublishSeconds']>=o['DurationSeconds']-.1,p
    assert m['TotalSeconds']>=m['PublishSeconds'],p
    assert all(0<=s['Outstanding']<=o['MaxOutstanding'] for s in m['Samples']),p
    if variant!='before':assert r['Environment']['CoreClrSha256'].lower()==expected_hash,p
    assert r['ResourcePrefix'] not in seen,p
    seen.add(r['ResourcePrefix']);trials+=1;inputs+=m['Inputs'];deliveries+=m['Deliveries']
assert trials==93,trials
assert not list((base/'confirmed-crashes').glob('*.dmp'))
result={'trials':trials,'inputs':inputs,'acknowledged_deliveries':deliveries,'missing':0,'duplicates':0,'invalid':0,'worker_failures':0,'unique_resource_prefixes':len(seen),'source_revision':'77c20ea354919fd25ae300e49c5de7f3ed8da598','coreclr_sha256':expected_hash}
(base/'confirmed-validation.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
